<?php
/**
 * Shared site content: contact details, packages, destinations, vehicles and gallery.
 * Edit values here once and every page picks them up.
 *
 * See assets/images/destinations/credits.md for destination photo credits and licenses.
 */

// Temporary switch for package route, pickup and drop-off fields.
const PACKAGE_ROUTE_FIELDS_VISIBLE = false;

$site = [
    'name'      => 'Reach Dream Travel',
    'phone'     => '+91 98883 51723',
    'phoneLink' => '+919888351723',
    'otherPhones' => [
        ['phone' => '+91 98054 02695', 'phoneLink' => '+919805402695'],
    ],
    'whatsapp'  => '919816716800',
    'email'     => 'reachdreamtravel@gmail.com',
    'address'   => '',
];
require_once dirname(__DIR__) . '/backend/site-settings.php';
$site = array_replace($site, site_contact_settings());

/*
 * Approximate road times from our base. Real times depend on traffic, weather and stops.
 */
$driveTimes = [
    ['Shimla', '7–8 hrs', 'shimla'],
    ['Manali', '9–10 hrs', 'manali'],
    ['Kasol', 'about 9 hrs', 'kasol'],
    ['Kinnaur', '2 days (night in Shimla)', 'kinnaur'],
    ['Spiti Valley', '3 days (via Kinnaur)', 'spiti'],
    ['Chandratal', '2 days (night in Manali)', 'chandratal'],
];

/** Escape a value for HTML output. */
function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function site_phone_numbers(): array
{
    global $site;

    $phones = [[
        'phone' => (string) ($site['phone'] ?? ''),
        'phoneLink' => (string) ($site['phoneLink'] ?? ''),
    ]];

    foreach (($site['otherPhones'] ?? []) as $phone) {
        if (!is_array($phone)) {
            continue;
        }

        $phones[] = [
            'phone' => (string) ($phone['phone'] ?? ''),
            'phoneLink' => (string) ($phone['phoneLink'] ?? ''),
        ];
    }

    return array_values(array_filter($phones, static fn($phone) => $phone['phone'] !== '' && $phone['phoneLink'] !== ''));
}

function site_phone_text(string $separator = ' / '): string
{
    return implode($separator, array_column(site_phone_numbers(), 'phone'));
}

function format_price($amount): string
{
    return '₹' . number_format((int) $amount, 0, '.', ',');
}

/** WhatsApp link with a prefilled message. */
function wa_link(string $message = 'Hello Reach Dream Travel, I would like to plan a trip.'): string
{
    global $site;
    return 'https://wa.me/' . $site['whatsapp'] . '?text=' . rawurlencode($message);
}

/** Resolve a photo to its category folder and optional thumbnail. */
function img(string $name, bool $small = false): string
{
    if (preg_match('~^https?://~i', $name)) {
        return $name;
    }
    $fileName = basename($name);
    $extension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $baseName = $extension !== '' ? pathinfo($fileName, PATHINFO_FILENAME) : $fileName;
    $stayPrefixes = ['camping', 'cottage', 'hotel-', 'kinnaur-camps', 'room-', 'tent-', 'tents-'];
    $isStay = false;
    foreach ($stayPrefixes as $prefix) {
        if (str_starts_with($baseName, $prefix)) {
            $isStay = true;
            break;
        }
    }
    $folder = $baseName === 'road-van' ? 'car' : ($isStay ? 'stays' : 'destinations');
    $absoluteFolder = dirname(__DIR__) . '/assets/images/' . $folder;
    if (!in_array($extension, ['jpg', 'jpeg', 'png', 'webp'], true)) {
        $extension = 'jpg';
        foreach (['jpg', 'jpeg', 'png', 'webp'] as $candidate) {
            if (is_file($absoluteFolder . '/' . $baseName . '.' . $candidate)) {
                $extension = $candidate;
                break;
            }
        }
    }
    $imagePath = 'assets/images/' . $folder . '/' . $baseName . '.' . $extension;
    if ($small) {
        $thumbnailPath = 'assets/images/' . $folder . '/' . $baseName . '-sm.jpg';
        if (is_file($absoluteFolder . '/' . $baseName . '-sm.jpg')) {
            return $thumbnailPath;
        }
    }
    return $imagePath;
}

function destination_url(string $slug): string
{
    return 'destinations.php?destination=' . rawurlencode($slug) . '#' . rawurlencode($slug);
}

/* ---------------------------------------------------------------------------
 * Tour packages. Every package includes pickup and drop.
 * 'cat' drives the filters on packages.php.
 * ------------------------------------------------------------------------- */
$packageCategories = ['all' => 'All packages', 'domestic' => 'Domestic', 'international' => 'International', 'nature' => 'Nature', 'heritage' => 'Heritage', 'himachal' => 'Himachal tours', 'trekking' => 'Trekking', 'camping' => 'Camping', 'religious' => 'Religious / Temple', 'solo' => 'Solo trips', 'new-year' => 'New Year', 'group' => 'Group tours', 'adventure' => 'Adventure / Activities', 'special' => 'Special interest', 'hills' => 'Hill stations', 'road' => 'Long road trips', 'north' => 'Northern India'];
$packageFilterCategories = ['all' => 'All packages', 'nature' => 'Nature', 'heritage' => 'Heritage', 'himachal' => 'Himachal tours', 'trekking' => 'Trekking', 'camping' => 'Camping', 'religious' => 'Religious / Temple', 'group' => 'Group tours', 'adventure' => 'Adventure / Activities'];

$customRoute = static function (string $title, string $label, string $category, string $season, string $route, string $overview, array $highlights, string $image): array {
    return [
        'title' => $title, 'label' => $label, 'cat' => $category,
        'duration' => 'Custom duration', 'short' => 'Flexible', 'popular' => false,
        'image' => $image, 'difficulty' => 'Planned around your group', 'season' => $season,
        'start' => 'Pickup point by arrangement', 'end' => 'Drop-off point by arrangement',
        'route' => $route, 'overview' => $overview, 'highlights' => $highlights,
        'days' => [['Plan your trip', 'Share your dates, group size and interests. We’ll suggest a route and pace that fit your plans and the season.']],
    ];
};

$packages = [
    'shimla-spiti-kinnaur' => [
        'title' => 'Spiti Valley via Kinnaur', 'label' => 'Our biggest road trip', 'cat' => 'road',
        'duration' => '8 days · 7 nights', 'short' => '8D · 7N', 'popular' => true,
        'image' => 'spiti-key-sunset', 'difficulty' => 'Moderate', 'season' => 'June – October',
        'start' => 'Your home or hotel', 'end' => 'Your home or hotel',
        'route' => 'Shimla · Kalpa · Nako · Tabo · Kaza · Manali',
        'overview' => 'A full loop through the high Himalaya. We drive to Shimla, then through Kinnaur’s apple orchards into Spiti’s cold desert of old monasteries and clear night skies. We come back through Manali.',
        'highlights' => ['Kinner Kailash mountain views from Kalpa', 'Nako Lake and village', 'Tabo Monastery, over 1,000 years old', 'Key Monastery above the Spiti river', 'Kunzum Pass on the way to Manali', 'Nights in simple, cosy homestays'],
        'days' => [
            ['Drive to Shimla', 'Morning pickup from your home or hotel. About 7–8 hours by road. Evening walk on Mall Road.'],
            ['Shimla to Sarahan', 'Drive along the Sutlej river to Sarahan and visit the Bhimakali Temple.'],
            ['Sarahan to Kalpa', 'Through apple orchards to Kalpa. See the Kinner Kailash peaks at sunset.'],
            ['Kalpa to Tabo', 'Stop at Nako Lake, then continue to Tabo and its old monastery.'],
            ['Tabo to Kaza', 'Visit Dhankar Monastery on its cliff, then reach Kaza, the main town of Spiti.'],
            ['Around Kaza', 'Key Monastery, Kibber village and the high village of Langza.'],
            ['Kaza to Manali', 'Cross Kunzum Pass. Visit Chandratal Lake if the road is open.'],
            ['Return journey', 'Drive back from Manali. Drop at your home or hotel.'],
        ],
    ],
    'shimla-kullu-manali' => [
        'title' => 'Shimla · Kullu · Manali', 'label' => 'Most loved hill trip', 'cat' => 'hills',
        'duration' => '6 days · 5 nights', 'short' => '6D · 5N', 'popular' => false,
        'image' => 'solang', 'difficulty' => 'Easy', 'season' => 'All year (snow Dec – Feb)',
        'start' => 'Your home or hotel', 'end' => 'Your home or hotel',
        'route' => 'Shimla · Kufri · Kullu · Manali · Solang · Atal Tunnel',
        'overview' => 'A family-friendly loop with time in Shimla and Manali, mountain scenery, rivers and a drive through the Atal Tunnel.',
        'highlights' => ['Mall Road and the Ridge in Shimla', 'Kufri hills', 'River rafting stop in Kullu', 'Hidimba Temple and Old Manali', 'Solang Valley snow', 'Drive through the Atal Tunnel'],
        'days' => [
            ['Drive to Shimla', 'Pickup from your home or hotel. About 7–8 hours by road. Evening free in Shimla.'],
            ['Shimla and Kufri', 'The Ridge, Jakhu Temple and Mall Road, plus a trip up to Kufri.'],
            ['Shimla to Manali', 'Drive through the Kullu valley (about 8 hours). Optional river rafting on the way.'],
            ['Manali sightseeing', 'Hidimba Temple, Vashisht hot springs, Old Manali and Mall Road.'],
            ['Solang & Atal Tunnel', 'Snow fun at Solang Valley and a drive through the Atal Tunnel to Sissu (weather permitting).'],
            ['Return journey', 'Drive back from Manali. Drop at your home or hotel.'],
        ],
    ],
    'shimla-local' => [
        'title' => 'Shimla – Kufri – Narkanda', 'label' => 'Nature & hill station', 'cat' => 'nature hills',
        'duration' => '5 days · 4 nights', 'short' => '5D · 4N', 'popular' => false,
        'image' => 'sanjauli', 'difficulty' => 'Easy', 'season' => 'All year',
        'start' => 'Your home or hotel', 'end' => 'Your home or hotel',
        'route' => 'Shimla · Mall Road · Kufri · Narkanda',
        'overview' => 'The easiest hill break. Cool air, old British buildings, pine forests and a day out to Kufri and Narkanda.',
        'highlights' => ['Mall Road and the Ridge', 'Jakhu Temple', 'Viceregal Lodge', 'Kufri and Narkanda day trip'],
        'days' => [
            ['Drive to Shimla', 'Pickup from your home or hotel. About 7–8 hours by road.'],
            ['Shimla sightseeing', 'Jakhu Temple, the Ridge, Christ Church, Viceregal Lodge and Mall Road.'],
            ['Kufri & Narkanda', 'A day trip to Kufri and Narkanda for mountain views (and snow in winter).'],
            ['Return journey', 'Relaxed breakfast, then drive back home.'],
        ],
    ],
    'shakti-peeths-himachal' => [
        'title' => 'Himachal Pradesh – 6 Shakti Peeth', 'label' => 'Temple & pilgrimage circuit', 'cat' => 'religious',
        'duration' => '3 days · 2 nights', 'short' => '3D · 2N', 'popular' => false,
        'image' => 'hidimba', 'difficulty' => 'Easy', 'season' => 'All year',
        'start' => 'Your home or hotel', 'end' => 'Your home or hotel',
        'route' => 'Chintpurni · Jwalamukhi · Kangra · Chamunda Devi · Baglamukhi · Naina Devi',
        'overview' => 'A three-day pilgrimage connecting the six Shakti Peeth temples named for this Himachal Pradesh route. Temple visits and driving order can be planned around your dates and local conditions.',
        'highlights' => ['Chintpurni Temple', 'Jwalamukhi Temple', 'Kangra Temple', 'Chamunda Devi Temple', 'Baglamukhi Temple', 'Naina Devi Temple'],
        'days' => [
            ['Chintpurni & Jwalamukhi', 'Visit Chintpurni Temple and Jwalamukhi Temple. The travel order can be adjusted to your pickup point.'],
            ['Kangra & Chamunda Devi', 'Continue to Kangra Temple and Chamunda Devi Temple, allowing time for darshan at both shrines.'],
            ['Baglamukhi & Naina Devi', 'Visit Baglamukhi Temple and Naina Devi Temple, then begin the return journey.'],
        ],
    ],
    'kinnaur-chitkul' => [
        'title' => 'Kinnaur & Chitkul', 'label' => 'Villages near the Tibet border', 'cat' => 'road',
        'duration' => '6 days · 5 nights', 'short' => '6D · 5N', 'popular' => false,
        'image' => 'kinnaur-sangla', 'difficulty' => 'Easy – moderate', 'season' => 'April – November',
        'start' => 'Your home or hotel', 'end' => 'Your home or hotel',
        'route' => 'Shimla · Sangla · Chitkul · Kalpa',
        'overview' => 'A shorter trip into the high mountains. Visit Chitkul, the last village on the road to Tibet, and wake up to snow peaks in Kalpa.',
        'highlights' => ['Sangla valley and the Baspa river', 'Chitkul village', 'Sunrise over Kinner Kailash from Kalpa', 'Apple orchards (Aug – Oct)'],
        'days' => [
            ['Drive to Shimla', 'Pickup from your home or hotel. About 7–8 hours by road.'],
            ['Shimla to Sangla', 'Along the Sutlej and into the green Sangla valley.'],
            ['Chitkul', 'Morning in Chitkul village by the river. Evening back in Sangla.'],
            ['Sangla to Kalpa', 'Short drive to Kalpa. Views of the Kinner Kailash peaks.'],
            ['Kalpa to Shimla', 'Drive back to Shimla with stops along the river.'],
            ['Return journey', 'Drive back from Shimla. Drop at your home or hotel.'],
        ],
    ],
    'kasol-parvati' => [
        'title' => 'Kasol & Parvati Valley', 'label' => 'Riverside rest', 'cat' => 'nature',
        'duration' => '4 days · 3 nights', 'short' => '4D · 3N', 'popular' => false,
        'image' => 'kasol-town', 'difficulty' => 'Easy', 'season' => 'March – June, Sept – Nov',
        'start' => 'Your home or hotel', 'end' => 'Your home or hotel',
        'route' => 'Kasol · Manikaran · Tosh · Chalal',
        'overview' => 'Slow, relaxing days by the Parvati river — pine forests, cafés, hot springs and short village walks.',
        'highlights' => ['Riverside cafés in Kasol', 'Manikaran Sahib Gurudwara and hot springs', 'Forest walk to Chalal', 'Tosh village views'],
        'days' => [
            ['Drive to Kasol', 'Pickup from your home or hotel. About 9 hours by road. Evening by the river.'],
            ['Manikaran & Tosh', 'Visit Manikaran Sahib, then drive up to Tosh village.'],
            ['Chalal & free time', 'Easy forest walk to Chalal and a free afternoon in Kasol.'],
            ['Return journey', 'Drive back from Kasol. Drop at your home or hotel.'],
        ],
    ],
    'chandratal-lahaul' => [
        'title' => 'Chandratal & Lahaul', 'label' => 'Through the Atal Tunnel', 'cat' => 'nature camping',
        'duration' => '5 days · 4 nights', 'short' => '5D · 4N', 'popular' => false,
        'image' => 'chandratal', 'difficulty' => 'Moderate', 'season' => 'Mid June – early October',
        'start' => 'Your home or hotel', 'end' => 'Your home or hotel',
        'route' => 'Manali · Atal Tunnel · Sissu · Chandratal',
        'overview' => 'Drive through the Atal Tunnel into Lahaul, then on a rough mountain road to Chandratal — a blue lake at 4,300 m. We use a 4×4 for the last part.',
        'highlights' => ['Atal Tunnel and Sissu waterfall', 'Chandra river valley', 'Night in camps under the stars', 'Sunrise at Chandratal Lake'],
        'days' => [
            ['Drive to Manali', 'Pickup from your home or hotel. About 9–10 hours by road.'],
            ['Manali to Sissu', 'Through the Atal Tunnel into Lahaul. Afternoon at Sissu waterfall.'],
            ['Sissu to Chandratal', 'Along the Chandra river to the lake. Night in camps nearby.'],
            ['Chandratal to Manali', 'Sunrise at the lake, then back to Manali.'],
            ['Return journey', 'Drive back from Manali. Drop at your home or hotel.'],
        ],
    ],
    'golden-triangle-delhi-agra-jaipur' => [
        'title' => 'Golden Triangle', 'label' => 'Classic India loop', 'cat' => 'heritage',
        'duration' => '4 days · 3 nights', 'short' => '4D · 3N', 'popular' => true,
        'image' => 'taj-mahal-agra', 'difficulty' => 'Easy', 'season' => 'All year',
        'start' => 'Delhi airport or hotel', 'end' => 'Delhi airport or hotel',
        'route' => 'Delhi · Agra · Jaipur',
        'overview' => 'A compact India circuit with the capital, a Mughal masterpiece and a royal Rajasthani city. You see the key monuments without the long travel fatigue.',
        'highlights' => ['Red Fort and Jama Masjid in Delhi', 'Sunrise at the Taj Mahal', 'Agra Fort and local artisan streets', 'Amber Fort and Hawa Mahal in Jaipur', 'Heritage hotel stays'],
        'days' => [
            ['Arrival in Delhi', 'Pick-up from the airport or your hotel. Easy city check-in and an evening walk around Connaught Place or Chandni Chowk.'],
            ['Delhi to Agra', 'Drive to Agra after breakfast. Visit Agra Fort and evening markets.'],
            ['Taj Mahal and Jaipur', 'Early sunrise at the Taj Mahal, then continue to Jaipur with a stop for lunch.'],
            ['Jaipur highlights', 'Amber Fort, City Palace and local bazaars before your return to Delhi.'],
        ],
    ],
    'rajasthan-heritage-trail' => [
        'title' => 'Rajasthan Heritage Trail', 'label' => 'Palaces, forts & desert nights', 'cat' => 'heritage',
        'duration' => '6 days · 5 nights', 'short' => '6D · 5N', 'popular' => false,
        'image' => 'jodhpur-jaswant-thada', 'difficulty' => 'Easy', 'season' => 'October – March',
        'start' => 'Delhi airport or hotel', 'end' => 'Delhi airport or hotel',
        'route' => 'Jaipur · Jodhpur · Jaisalmer · Udaipur',
        'overview' => 'A royal route through Rajasthan’s forts, havelis and desert towns. The trip balances heritage sightseeing with relaxed evenings and local food.',
        'highlights' => ['Amber Fort and City Palace in Jaipur', 'Mehrangarh Fort in Jodhpur', 'Golden sands of Jaisalmer', 'Lake Palace views in Udaipur', 'Rajasthani folk culture and cuisine'],
        'days' => [
            ['Arrive in Jaipur', 'Meet in Jaipur and settle into a heritage stay. Evening walk in the bazaars.'],
            ['Jaipur city tour', 'Amber Fort, Hawa Mahal, Jantar Mantar and local craft markets.'],
            ['Jaipur to Jodhpur', 'Drive to Jodhpur for fort views and the blue city streets.'],
            ['Jodhpur to Jaisalmer', 'Continue to the golden desert city and enjoy a sunset desert experience.'],
            ['Jaisalmer to Udaipur', 'Drive onward to Udaipur for lakeside evenings and palace views.'],
            ['Return journey', 'Drive back to Delhi or depart from Udaipur depending on your plan.'],
        ],
    ],
    'delhi-agra-weekend' => [
        'title' => 'Delhi & Agra Weekend', 'label' => 'Quick cultural escape', 'cat' => 'heritage',
        'duration' => '3 days · 2 nights', 'short' => '3D · 2N', 'popular' => false,
        'image' => 'taj-mahal-agra', 'difficulty' => 'Easy', 'season' => 'All year',
        'start' => 'Delhi airport or hotel', 'end' => 'Delhi airport or hotel',
        'route' => 'Delhi · Agra',
        'overview' => 'A smooth short trip for couples, families or friends who want a fast cultural getaway with iconic monuments, great food and no complicated planning.',
        'highlights' => ['Old Delhi heritage lanes', 'Red Fort and India Gate', 'Sunrise Taj Mahal visit', 'Agra Fort and marble market'],
        'days' => [
            ['Arrival in Delhi', 'Airport or hotel pickup and a guided evening in central Delhi.'],
            ['Delhi sightseeing', 'Old Delhi, Raj Ghat, India Gate and local food stops.'],
            ['Agra day trip', 'Drive to Agra for the Taj Mahal, Agra Fort and a relaxed evening return to Delhi.'],
        ],
    ],
];

$packages += [
    'nainital' => $customRoute('Nainital Holiday', 'Lake views & easy hill walks', 'north', 'March–June, September–November', 'Naini Lake · Mall Road · Naina Devi Temple', 'A relaxed Kumaon hill break centred on Naini Lake, with time for boating, Mall Road and a visit to Naina Devi Temple.', ['Boating on Naini Lake', 'Walk along Mall Road', 'Visit Naina Devi Temple'], 'nainital'),
    'bhimtal' => $customRoute('Bhimtal Lake Holiday', 'Lake island & quiet hill views', 'north nature hills', 'March-June, September-November', 'Bhimtal Lake - Lake island - Boating - Kumaon viewpoints', 'A peaceful Kumaon lake break in Bhimtal, with boating on Bhimtal Lake, views of the lake island and easy time around nearby hill viewpoints.', ['Boating on Bhimtal Lake', 'Views of the island in the lake', 'Slow walks by the lakeside', 'Nearby Kumaon hill viewpoints'], 'bhimtal'),
    'mussoorie' => $customRoute('Mussoorie Holiday', 'The Queen of Hills', 'north', 'September–June', 'George Everest Peak · Mall Road · Mussoorie Lake · Ropeway to Bhatta Falls · Lal Tibba · Scenic Cafe · Cloud End · Kempty Water Fall', 'Take in sunrise views from George Everest Peak, Mussoorie’s mountain viewpoints, lakes, waterfalls and forest edges, with scenic walks and unhurried time on Mall Road.', ['George Everest Peak sunrise', 'Mall Road', 'Mussoorie Lake', 'Ropeway to Bhatta Falls', 'Lal Tibba', 'Scenic Cafe', 'Cloud End', 'Kempty Water Fall'], 'george-everest-peak'),
    'chakrata' => $customRoute('Chakrata Holiday', 'Quiet hills & forest viewpoints', 'north nature hills', 'March–June, September–November', 'Chakrata View Point · Tiger Falls · Budher Caves · Deoban Chakrata · Chilmiri Neck · Ram Tal Horticultural Garden', 'A peaceful Chakrata hill break with waterfalls, viewpoints, forest drives and relaxed time around its quieter mountain roads.', ['Chakrata View Point', 'Tiger Falls', 'Budher Caves', 'Deoban Chakrata', 'Chilmiri Neck', 'Ram Tal Horticultural Garden'], 'snow-peaks'),
    'rishikesh' => $customRoute('Rishikesh Getaway', 'River, yoga & adventure', 'north adventure religious', 'February–May, August–October', 'Lakshman Jhula · Beatles Ashram · River Rafting · Yoga Retreats', 'A riverside Rishikesh escape with spiritual landmarks, yoga retreats and seasonal river rafting.', ['Lakshman Jhula', 'Beatles Ashram', 'River rafting, when available', 'Yoga retreats'], 'rishikesh'),
    'solo-rishikesh-activity-break' => array_replace($customRoute('Solo Rishikesh Activity Break', 'Solo river & yoga escape', 'solo adventure north', 'February–May, August–October', 'Lakshman Jhula · Beatles Ashram · River Rafting · Yoga Retreats', 'A flexible solo-friendly Rishikesh trip with rafting, yoga, cafe time and easy sightseeing around the Ganga.', ['River rafting, when available', 'Yoga retreat or drop-in sessions', 'Beatles Ashram visit', 'Lakshman Jhula and riverfront cafes'], 'rishikesh'), ['duration' => '3 days · 2 nights', 'short' => '3D · 2N']),
    'solo-manali-adventure-break' => array_replace($customRoute('Solo Manali Adventure Break', 'Snow, cafes & activities', 'solo adventure hills', 'All year (snow Dec–Feb)', 'Manali · Solang Valley · Atal Tunnel · Old Manali', 'A solo-friendly Manali break with cafe walks, snow or mountain activities and a scenic drive towards Solang and the Atal Tunnel.', ['Solang Valley activities, subject to weather', 'Atal Tunnel and Sissu drive, when accessible', 'Old Manali cafes and walks', 'Hidimba Temple and local sightseeing'], 'solang'), ['duration' => '4 days · 3 nights', 'short' => '4D · 3N']),
    'solo-kasol-backpacking-break' => array_replace($customRoute('Solo Kasol Backpacking Break', 'Riverside cafes & short walks', 'solo nature camping', 'March–June, September–November', 'Kasol · Chalal · Manikaran · Tosh', 'A relaxed solo backpacking-style trip through Kasol and the Parvati Valley with riverside cafes, short walks and optional camping.', ['Kasol riverside cafes', 'Forest walk to Chalal', 'Manikaran Sahib and hot springs', 'Tosh village or camping add-on'], 'kasol-town'), ['duration' => '4 days · 3 nights', 'short' => '4D · 3N']),
    'solo-chakrata-nature-activity' => array_replace($customRoute('Solo Chakrata Nature Activity Trip', 'Waterfalls, caves & viewpoints', 'solo nature adventure hills', 'March–June, September–November', 'Chakrata View Point · Tiger Falls · Budher Caves · Deoban · Chilmiri Neck', 'A quiet solo nature trip around Chakrata with waterfall time, forest viewpoints, caves and slow mountain drives.', ['Tiger Falls visit', 'Budher Caves outing', 'Deoban forest viewpoint', 'Chilmiri Neck sunset stop'], 'snow-peaks'), ['duration' => '3 days · 2 nights', 'short' => '3D · 2N']),
    'solo-dharamshala-triund-activity' => array_replace($customRoute('Solo Dharamshala & Triund Activity Trip', 'Culture, cafes & trekking', 'solo trekking adventure', 'March–June, September–November', 'Dharamshala · McLeod Ganj · Dharamkot · Triund', 'A solo-friendly Dharamshala and McLeod Ganj trip with Tibetan culture, cafe time, forest walks and a Triund trek plan.', ['Triund trek, subject to weather and local guidance', 'Dharamkot cafes and walks', 'Dalai Lama Temple complex', 'Bhagsu waterfall and local sightseeing'], 'dharamshala'), ['duration' => '4 days · 3 nights', 'short' => '4D · 3N']),
    'haridwar' => $customRoute('Haridwar Pilgrimage', 'Ganga aarti & temple visits', 'religious north', 'All year', 'Har Ki Pauri · Mansa Devi Temple · Chandi Devi Temple', 'A devotional Haridwar trip centred on the Ganga ghats, evening aarti and hilltop temple visits.', ['Har Ki Pauri', 'Mansa Devi Temple', 'Chandi Devi Temple'], 'rishikesh'),
    'auli' => $customRoute('Auli Snow & Ski Escape', 'High Himalayan views', 'nature', 'November–March for snow and skiing', 'Auli · Himalayan viewpoints', 'A winter trip to Auli, with the option to plan around snow conditions, ski activities and cable car visits.', ['Skiing, subject to snow and operations', 'Cable car ride, subject to operations', 'Views of snow-covered Himalayan peaks'], 'snow-peaks'),
    'jim-corbett' => $customRoute('Jim Corbett Wildlife Trip', 'Forest & wildlife', 'nature', 'November–June; safari zones vary', 'Jim Corbett National Park · Kosi River', 'Plan a wildlife-focused break around available safari zones, park rules and your travel dates.', ['Jeep safari, subject to permits and zone availability', 'Wildlife spotting', 'Kosi River scenery'], 'jim-corbett'),
    'kashmir-valley' => $customRoute('Jammu and Kashmir Tour', 'Lakes, gardens & mountain valleys', 'north', 'April–October for sightseeing; November–February for snow', 'Srinagar · Gulmarg · Pahalgam · Sonamarg', 'Build a Jammu and Kashmir journey around Srinagar’s lake life, Gulmarg’s snow and gondola experiences, Pahalgam’s valleys and Sonamarg’s glacier views. Winter activities depend on weather and local operations.', ['Srinagar for Dal Lake shikara rides, houseboats, Shalimar Bagh and Nishat Garden', 'Gulmarg for skiing, Gulmarg Gondola and Apharwat Peak', 'Pahalgam for Betaab Valley, Aru Valley and the Lidder River', 'Sonamarg for Meadow of Gold scenery and Thajiwas Glacier'], 'srinagar'),
    'dharamshala-mcleodganj' => array_replace($customRoute('Dharamshala – McLeod Ganj', 'Nature, culture & trekking', 'nature trekking adventure', 'Plan around your dates', 'Dharamshala · McLeod Ganj · Dharamkot · Triund', 'A five-day mountain trip with a Triund trek and time around Dharamshala and McLeod Ganj. Trek conditions depend on weather and local guidance.', ['Triund Trek', 'Dharamkot', 'Dalai Lama visit', 'Cricket Stadium visit', 'Nandi visit'], 'dharamshala'), ['duration' => '5 days · 4 nights', 'short' => '5D · 4N']),
    'triund-trek' => array_replace($customRoute('Triund Trek', 'Dharamshala / McLeodganj trek', 'trekking adventure himachal nature', 'March–June, September–November', 'Dharamshala · McLeodganj · Triund', 'A classic Dhauladhar trek from the Dharamshala and McLeodganj side, planned with local conditions, guide support and guest fitness in mind.', ['Location: Dharamshala / McLeodganj', 'Altitude: approx. 2,850 m (9,350 ft)', 'Dhauladhar views from the ridge', 'Trek pace planned around your group'], 'triund-dhauladhar'), ['duration' => 'Custom trek duration', 'short' => 'Trek']),
    'kareri-lake-trek' => array_replace($customRoute('Kareri Lake Trek', 'Kangra high-altitude lake trek', 'trekking adventure himachal nature', 'May–June, September–October', 'Kangra · Kareri village · Kareri Lake', 'A scenic Kangra trek towards Kareri Lake, with forest trails, mountain views and logistics planned around route conditions.', ['Location: Kangra', 'Altitude: approx. 4,350 m (14,270 ft)', 'Lake-side Himalayan scenery', 'Guide, stays and transport planned on request'], 'dharamshala'), ['duration' => 'Custom trek duration', 'short' => 'Trek']),
    'rupin-pass-trek' => array_replace($customRoute('Rupin Pass Trek', 'Shimla / Rohru region trek', 'trekking adventure himachal nature', 'May–June, September–October', 'Shimla · Rohru region · Rupin Pass', 'A high-altitude trek through the Shimla and Rohru side, planned carefully around weather, trail conditions and acclimatisation needs.', ['Location: Shimla / Rohru region', 'Altitude: approx. 4,572 m (15,000 ft)', 'High-pass Himalayan trail', 'Best planned with guide support and buffer time'], 'kinnaur-peaks'), ['duration' => 'Custom trek duration', 'short' => 'Trek']),
    'buran-ghati-trek' => array_replace($customRoute('Buran Ghati Trek', 'Shimla region pass trek', 'trekking adventure himachal nature', 'May–June, September–October', 'Shimla region · Buran Ghati', 'A challenging Shimla-region trek with high mountain scenery, village approaches and pass-crossing planning based on current trail conditions.', ['Location: Shimla region', 'Altitude: approx. 4,572 m (15,000 ft)', 'High-pass trek experience', 'Route and camps planned around season and group pace'], 'shimla-snow'), ['duration' => 'Custom trek duration', 'short' => 'Trek']),
    'prashar-lake-trek' => array_replace($customRoute('Prashar Lake Trek', 'Mandi lake trek', 'trekking adventure himachal nature', 'All year, best in clear weather', 'Mandi · Prashar Lake', 'A short and rewarding trek around Mandi leading to Prashar Lake, ideal for guests who want mountain views without a very long expedition.', ['Location: Mandi', 'Altitude: approx. 2,730 m (8,960 ft)', 'Prashar Lake and temple views', 'Good option for a shorter trek plan'], 'meadow'), ['duration' => 'Custom trek duration', 'short' => 'Trek']),
    'bijli-mahadev-trek' => array_replace($customRoute('Bijli Mahadev Trek', 'Kullu temple trek', 'trekking adventure religious himachal nature', 'March–June, September–November', 'Kullu · Bijli Mahadev', 'A Kullu trek to the Bijli Mahadev temple area, combining a spiritual stop with open valley views and a flexible trek plan.', ['Location: Kullu', 'Altitude: approx. 2,438 m (8,000 ft)', 'Bijli Mahadev temple visit', 'Kullu valley views'], 'parvati'), ['duration' => 'Custom trek duration', 'short' => 'Trek']),
    'indrahara-pass-trek' => array_replace($customRoute('Indrahara Pass Trek', 'Dharamshala high-pass trek', 'trekking adventure himachal nature', 'May–June, September–October', 'Dharamshala · McLeodganj · Indrahara Pass', 'A demanding Dharamshala-side trek towards Indrahara Pass, planned with guides, weather checks and a careful mountain pace.', ['Location: Dharamshala', 'Altitude: approx. 4,350 m (14,270 ft)', 'Dhauladhar high-pass scenery', 'Best suited to prepared trekkers'], 'trek-lahaul'), ['duration' => 'Custom trek duration', 'short' => 'Trek']),
    'fairy-forest-pulga' => array_replace($customRoute('The Fairy Forest (Pulga)', 'Pulga forest escape', 'nature himachal', 'March–June, September–November', 'Kasol · Barshaini · Pulga · Fairy Forest', 'A nature-focused escape to Pulga and its Fairy Forest, planned around peaceful forest walks, village time and Parvati Valley scenery.', ['Location: Pulga, Parvati Valley', 'Forest walks around Pulga', 'Village cafes and slow nature time', 'Best planned with Kasol or Tosh'], 'kasol-town'), ['duration' => 'Custom duration', 'short' => 'Nature']),
    'kalatop-wildlife-sanctuary' => array_replace($customRoute('Kalatop Wildlife Sanctuary', 'Dalhousie forest reserve', 'nature wildlife himachal', 'March–June, September–November', 'Dalhousie · Kalatop Wildlife Sanctuary · Khajjiar', 'A Dalhousie forest outing around Kalatop Wildlife Sanctuary, with deodar trails, quiet viewpoints and a relaxed nature-first plan.', ['Location: Dalhousie', 'Kalatop Wildlife Sanctuary forest trails', 'Combine with Khajjiar meadows', 'Good for families and nature lovers'], 'meadow'), ['duration' => 'Custom duration', 'short' => 'Nature']),
    'shimla-water-catchment-wildlife-sanctuary' => array_replace($customRoute('Shimla Water Catchment Wildlife Sanctuary', 'Mashobra forest walk', 'nature wildlife himachal', 'March–June, September–November', 'Shimla · Mashobra · Water Catchment Wildlife Sanctuary', 'A peaceful forest-side Shimla plan around Mashobra and the Water Catchment Wildlife Sanctuary, ideal for slow walks and quiet hill time.', ['Location: Mashobra / Shimla', 'Shimla Water Catchment Wildlife Sanctuary', 'Cool forest trails near Shimla', 'Easy add-on to a Shimla stay'], 'shimla-lodge'), ['duration' => 'Custom duration', 'short' => 'Nature']),
    'dhungri-van-vihar' => array_replace($customRoute('Dhungri Van Vihar', 'Manali cedar forest', 'nature himachal', 'All year', 'Manali · Dhungri Van Vihar · Hidimba Devi Temple', 'A Manali nature stop around Dhungri Van Vihar and the cedar forest near Hidimba Devi Temple, planned as a gentle local sightseeing experience.', ['Location: Manali', 'Dhungri Van Vihar cedar forest', 'Hidimba Devi Temple nearby', 'Easy walk for families and couples'], 'hidimba'), ['duration' => 'Custom duration', 'short' => 'Nature']),
    'shoja-jibhi-forest-escape' => array_replace($customRoute('Shoja & Jibhi Forest Escape', 'Seraj valley forest villages', 'nature himachal', 'March–June, September–November', 'Aut · Banjar · Jibhi · Shoja', 'A quiet forest escape through Shoja and Jibhi, with riverside time, village stays and gentle walks in the Seraj valley.', ['Location: Shoja & Jibhi', 'Forest village atmosphere', 'Riverside walks and valley viewpoints', 'Good slow-travel nature break'], 'forest-river'), ['duration' => 'Custom duration', 'short' => 'Nature']),
    'chail-wildlife-sanctuary' => array_replace($customRoute('Chail Wildlife Sanctuary', 'Chail forest retreat', 'nature wildlife himachal', 'March–June, September–November', 'Shimla · Chail · Chail Wildlife Sanctuary', 'A peaceful Chail forest retreat with sanctuary-side nature time, hill views and a slower alternative to busier Shimla routes.', ['Location: Chail', 'Chail Wildlife Sanctuary', 'Forest roads and hill viewpoints', 'Easy extension from Shimla'], 'shimla'), ['duration' => 'Custom duration', 'short' => 'Nature']),
    'dalhousie-khajjiar' => array_replace($customRoute('Dalhousie – Khajjiar', 'Nature & hill scenery', 'nature', 'Plan around your dates', 'Dalhousie · Khajjiar', 'A four-day nature break pairing Dalhousie with the meadows and mountain scenery of Khajjiar.', ['Dalhousie', 'Khajjiar meadows', 'Dhauladhar views'], 'khajjiar'), ['duration' => '4 days · 3 nights', 'short' => '4D · 3N']),
    'jammu-katra-patnitop' => $customRoute('Jammu, Katra & Patnitop', 'Pilgrimage & mountain air', 'heritage', 'Plan around your dates and local conditions', 'Jammu City · Katra · Vaishno Devi · Patnitop', 'Combine time in Jammu with a visit to Katra and the Vaishno Devi shrine, then add a relaxing stay in Patnitop.', ['Jammu City', 'Katra and Vaishno Devi shrine visit', 'Patnitop hill-station break'], 'snow-peaks'),
    'katra-vaishno-devi' => $customRoute('Katra / Vaishno Devi', 'Sacred pilgrimage base', 'religious north', 'Plan around your dates', 'Katra · Vaishno Devi Mandir', 'A focused pilgrimage package for Katra, the base town for the sacred journey to Vaishno Devi Mandir shrine.', ['Katra base town', 'Vaishno Devi Mandir shrine', 'Pilgrimage arrangements planned around your dates'], 'snow-peaks'),
    'char-dham-hemkund-sahib-yatra' => array_replace($customRoute('Char Dham & Hemkund Sahib Yatra', 'Sacred Uttarakhand pilgrimage', 'religious north', 'May–October, subject to route and shrine openings', 'Yamunotri · Gangotri · Kedarnath · Badrinath · Hemkund Sahib', 'A devotional Uttarakhand journey linking the Char Dham shrines with Hemkund Sahib. The route, halt points and trek days are planned around opening dates, road conditions and your group pace.', ['Yamunotri, source of the River Yamuna and known for natural hot springs', 'Gangotri, origin of the holy River Ganga in the greater Himalayas', 'Kedarnath, one of the 12 sacred Jyotirlingas of Lord Shiva', 'Badrinath, the revered holy shrine dedicated to Lord Vishnu', 'Hemkund Sahib, the high-altitude Gurudwara by a glacial lake'], 'snow-peaks'), ['duration' => 'Custom yatra duration', 'short' => 'Yatra']),
    'pathankot-nurpur-dharamshala-kangra' => $customRoute('Pathankot – Nurpur – Dharamshala – Kangra', 'Heritage & Himachal tour', 'heritage himachal', 'Plan around your dates', 'Pathankot · Nurpur · Dharamshala · Kangra', 'A heritage-focused route connecting Pathankot, Nurpur, Dharamshala and Kangra. Share your dates to plan the stops and pace.', ['Nurpur Fort', 'Dharamshala', 'Kangra heritage'], 'nurpur-fort'),
    'amritsar-pathankot-dalhousie' => array_replace($customRoute('Amritsar – Pathankot – Dalhousie', 'Punjab & Himachal tour', 'heritage nature', 'Plan around your dates', 'Amritsar · Pathankot · Dalhousie', 'A six-day route from Amritsar through Pathankot to Dalhousie, with sightseeing planned around your travel dates.', ['Amritsar', 'Pathankot', 'Dalhousie'], 'amritsar-golden-temple'), ['duration' => '6 days · 5 nights', 'short' => '6D · 5N']),
    'amritsar-katra' => array_replace($customRoute('Amritsar – Katra', 'Religious & pilgrimage tour', 'religious', 'Plan around your dates', 'Amritsar · Katra · Vaishno Devi', 'A four-day pilgrimage route from Amritsar to Katra. Shrine access and visit arrangements depend on permits and local conditions.', ['Amritsar', 'Katra', 'Vaishno Devi shrine'], 'amritsar-golden-temple'), ['duration' => '4 days · 3 nights', 'short' => '4D · 3N']),
    'dharamshala-mcleod-ganj-trek' => array_replace($customRoute('Dharamshala – McLeod Ganj', 'Nature, culture & trekking', 'nature trekking adventure', 'Plan around your dates', 'Dharamshala · McLeod Ganj · Dharamkot · Triund', 'A five-day mountain trip with a Triund trek and visits around Dharamshala and McLeod Ganj. Trek conditions depend on weather and local guidance.', ['Triund Trek', 'Dharamkot', 'Dalai Lama Temple complex', 'Cricket Stadium visit', 'Nandi visit'], 'dharamshala'), ['duration' => '5 days · 4 nights', 'short' => '5D · 4N', 'deprecated_duplicate_of' => 'dharamshala-mcleodganj']),
    'dalhousie-khajjiar-nature' => array_replace($customRoute('Dalhousie – Khajjiar', 'Nature & hill scenery', 'nature', 'Plan around your dates', 'Dalhousie · Khajjiar', 'A four-day nature break pairing Dalhousie with the meadows and mountain scenery of Khajjiar.', ['Dalhousie', 'Khajjiar meadows', 'Dhauladhar views'], 'khajjiar'), ['duration' => '4 days · 3 nights', 'short' => '4D · 3N', 'deprecated_duplicate_of' => 'dalhousie-khajjiar']),
    'shimla-kufri-narkanda' => array_replace($customRoute('Shimla – Kufri – Narkanda', 'Nature & hill station', 'nature hills', 'Plan around your dates', 'Shimla · Kufri · Narkanda', 'A five-day hill-station route through Shimla, Kufri and Narkanda, with sightseeing paced to your dates.', ['Shimla', 'Kufri', 'Narkanda'], 'shimla-city'), ['duration' => '5 days · 4 nights', 'short' => '5D · 4N', 'deprecated_duplicate_of' => 'shimla-local']),
    'himachal-six-shakti-peeth' => array_replace($customRoute('Himachal Pradesh – 6 Shakti Peeth', 'Temple & pilgrimage circuit', 'religious heritage', 'Plan around your dates', 'Chintpurni · Jwalamukhi · Kangra · Chamunda Devi · Baglamukhi · Naina Devi', 'A three-day pilgrimage circuit covering the six temples specified for this route. The temple order and driving plan can be confirmed around your dates.', ['Chintpurni Temple', 'Jwalamukhi Temple', 'Kangra Temple', 'Chamunda Devi Temple', 'Baglamukhi Temple', 'Naina Devi Temple'], 'hidimba'), ['duration' => '3 days · 2 nights', 'short' => '3D · 2N', 'deprecated_duplicate_of' => 'shakti-peeths-himachal']),
    'international-coming-soon' => array_replace($customRoute('International Packages', 'Coming soon', 'international', 'Coming soon', 'Coming Soon', 'International tour packages are coming soon. Contact us and we will help you plan once routes are announced.', ['International packages coming soon', 'Tell us your dream destination', 'We will update this section shortly'], 'hero-himachal'), ['duration' => 'Coming soon', 'short' => 'Soon']),
];

require_once __DIR__ . '/package-photos.php';
foreach ($packages as $slug => &$package) {
    $curatedImage = package_curated_image((string) $slug);
    if ($curatedImage !== null && empty($package['image_customized'])) {
        $package['image'] = $curatedImage;
    }
}
unset($package);
$defaultPackages = $packages;
require_once dirname(__DIR__) . '/backend/package-store.php';
$packages = package_catalog($packages);
require_once dirname(__DIR__) . '/backend/package-options.php';
foreach ($packages as &$package) {
    // Seed existing records while preserving each package's saved selections, including empty lists.
    $package += package_option_defaults();
}
unset($package);
foreach ($packages as &$package) {
    $categoryKeys = preg_split('/\s+/', trim((string) ($package['cat'] ?? ''))) ?: [];
    if (!in_array('international', $categoryKeys, true) && !in_array('domestic', $categoryKeys, true)) {
        array_unshift($categoryKeys, 'domestic');
        $package['cat'] = implode(' ', array_values(array_unique(array_filter($categoryKeys))));
    }
}
unset($package);
$routeImages = [
    'delhi-agra-weekend' => 'taj-mahal-agra',
    'golden-triangle-delhi-agra-jaipur' => 'taj-mahal-agra',
    'rajasthan-heritage-trail' => 'jodhpur-jaswant-thada',
];
foreach ($routeImages as $slug => $image) {
    if (isset($packages[$slug]) && empty($packages[$slug]['image_customized'])) {
        $packages[$slug]['image'] = $image;
    }
}
function package_auto_image(string $slug, array $package): string
{
    $curatedImage = package_curated_image($slug);
    if ($curatedImage !== null) {
        return $curatedImage;
    }
    $packageImages = [
        'triund-trek' => 'triund-dhauladhar',
        'kareri-lake-trek' => 'dharamshala',
        'rupin-pass-trek' => 'kinnaur-peaks',
        'buran-ghati-trek' => 'shimla-snow',
        'prashar-lake-trek' => 'meadow',
        'bijli-mahadev-trek' => 'parvati',
        'indrahara-pass-trek' => 'trek-lahaul',
        'fairy-forest-pulga' => 'kasol-town',
        'kalatop-wildlife-sanctuary' => 'meadow',
        'shimla-water-catchment-wildlife-sanctuary' => 'shimla-lodge',
        'dhungri-van-vihar' => 'hidimba',
        'shoja-jibhi-forest-escape' => 'forest-river',
        'chail-wildlife-sanctuary' => 'shimla',
    ];
    if (isset($packageImages[$slug])) {
        return $packageImages[$slug];
    }

    $text = strtolower($slug . ' ' . implode(' ', array_map('strval', [
        $package['title'] ?? '',
        $package['label'] ?? '',
        $package['route'] ?? '',
        $package['overview'] ?? '',
        implode(' ', array_map('strval', $package['highlights'] ?? [])),
    ])));

    $keywordImages = [
        'spiti' => 'spiti-key-sunset',
        'kinnaur' => 'kinnaur-sangla',
        'chitkul' => 'kinnaur-sangla',
        'manali' => 'solang',
        'solang' => 'solang',
        'shimla' => 'shimla-city',
        'kufri' => 'shimla-snow',
        'narkanda' => 'shimla-lodge',
        'kasol' => 'kasol-town',
        'parvati' => 'parvati',
        'chandratal' => 'chandratal',
        'lahaul' => 'chandratal-b',
        'delhi' => 'red-fort-delhi',
        'agra' => 'taj-mahal-agra',
        'taj' => 'taj-mahal-agra',
        'jaipur' => 'hawa-mahal-jaipur',
        'jaisalmer' => 'hawa-mahal-jaipur',
        'jodhpur' => 'jodhpur-jaswant-thada',
        'rajasthan' => 'hawa-mahal-jaipur',
        'desert' => 'hawa-mahal-jaipur',
        'nainital' => 'nainital',
        'bhimtal' => 'bhimtal',
        'mussoorie' => 'george-everest-peak',
        'chakrata' => 'forest-river',
        'tiger falls' => 'forest-river',
        'rishikesh' => 'rishikesh',
        'haridwar' => 'rishikesh',
        'auli' => 'manali-snow',
        'ski' => 'manali-snow',
        'corbett' => 'jim-corbett',
        'kashmir' => 'srinagar',
        'srinagar' => 'srinagar',
        'gulmarg' => 'snow-peaks',
        'pahalgam' => 'forest-river',
        'sonamarg' => 'sonamarg',
        'dharamshala' => 'dharamshala',
        'mcleod' => 'dharamshala',
        'triund' => 'triund-dhauladhar',
        'dalhousie' => 'meadow',
        'khajjiar' => 'khajjiar',
        'katra' => 'ranjit-sagar-dam',
        'vaishno' => 'ranjit-sagar-dam',
        'jammu' => 'ranjit-sagar-dam',
        'patnitop' => 'snow-peaks',
        'char dham' => 'snow-peaks',
        'kedarnath' => 'snow-peaks',
        'badrinath' => 'snow-peaks',
        'yamunotri' => 'snow-peaks',
        'gangotri' => 'snow-peaks',
        'hemkund' => 'snow-peaks',
        'pathankot' => 'nurpur-fort',
        'nurpur' => 'nurpur-fort',
        'kangra' => 'nurpur-fort',
        'amritsar' => 'amritsar-golden-temple',
    ];

    foreach ($keywordImages as $keyword => $image) {
        if (str_contains($text, $keyword)) {
            return $image;
        }
    }

    return (string) ($package['image'] ?? 'hero-himachal');
}
foreach ($packages as $slug => &$package) {
    if (empty($package['image_customized'])) {
        $package['image'] = package_auto_image((string) $slug, $package);
    }
}
unset($package);
require_once dirname(__DIR__) . '/backend/catalog-order.php';
$packages = app_catalog_order($packages, 'packages');
$allPackages = $packages;
$packages = array_filter($packages, 'app_catalog_is_active');
$publicPackages = array_filter($packages, static fn($package) => empty($package['deprecated_duplicate_of']));

/* ---------------------------------------------------------------------------
 * Destinations (destinations.php, footer and about page).
 * ------------------------------------------------------------------------- */
$destinations = [
    'shimla' => [
        'name' => 'Shimla', 'tagline' => 'The Queen of Hills', 'image' => 'shimla-church', 'altitude' => '2,200 m', 'best' => 'All year', 'drive' => '7–8 hrs by road',
        'text' => 'The closest big hill station. Old British buildings, Mall Road, pine forests and the famous toy train.',
        'see' => ['The Ridge & Christ Church', 'Mall Road', 'Jakhu Temple', 'Viceregal Lodge'],
        'packages' => ['shimla-local', 'shimla-kullu-manali'],
    ],
    'manali' => [
        'name' => 'Manali & Solang', 'tagline' => 'Snow and adventure', 'image' => 'manali-valley', 'altitude' => '2,050 m', 'best' => 'All year (snow Dec – Feb)', 'drive' => '9–10 hrs by road',
        'text' => 'Snow, rivers, old wooden temples and adventure sports. Also the starting point for the Atal Tunnel and Lahaul.',
        'see' => ['Hidimba Devi Temple', 'Old Manali', 'Solang Valley', 'Atal Tunnel & Sissu', 'Vashisht hot springs'],
        'packages' => ['shimla-kullu-manali', 'chandratal-lahaul', 'solo-manali-adventure-break'],
    ],
    'kasol' => [
        'name' => 'Kullu & Kasol', 'tagline' => 'Life by the river', 'image' => 'kasol-river', 'altitude' => '1,580 m', 'best' => 'March – June, Sept – Nov', 'drive' => 'About 9 hrs by road',
        'text' => 'Pine forests, a fast blue river and slow, peaceful days. Great for short walks, hot springs and cafés.',
        'see' => ['Kasol', 'Manikaran Sahib', 'Tosh & Chalal', 'Kullu shawl makers'],
        'packages' => ['kasol-parvati', 'shimla-kullu-manali', 'solo-kasol-backpacking-break'],
    ],
    'kinnaur' => [
        'name' => 'Kinnaur', 'tagline' => 'Apple orchards & snow peaks', 'image' => 'kinnaur-autumn', 'altitude' => '2,900 m (Kalpa)', 'best' => 'April – November', 'drive' => '2 days by road',
        'text' => 'Green valleys, apple orchards and wooden villages under the snowy Kinner Kailash mountains.',
        'see' => ['Sarahan', 'Sangla & Chitkul', 'Kalpa', 'Nako Lake'],
        'packages' => ['kinnaur-chitkul', 'shimla-spiti-kinnaur'],
    ],
    'spiti' => [
        'name' => 'Spiti Valley', 'tagline' => 'The cold desert', 'image' => 'spiti-key', 'altitude' => '3,800 m (Kaza)', 'best' => 'June – October', 'drive' => '3 days by road',
        'text' => 'A high, dry mountain valley with monasteries on cliffs, tiny villages and some of the clearest night skies in India.',
        'see' => ['Key Monastery', 'Dhankar Monastery', 'Tabo', 'Langza & Kibber', 'Pin Valley'],
        'packages' => ['shimla-spiti-kinnaur'],
    ],
    'chandratal' => [
        'name' => 'Chandratal & Lahaul', 'tagline' => 'The moon lake', 'image' => 'chandratal-b', 'altitude' => '4,300 m', 'best' => 'Mid June – early October', 'drive' => '2 days by road',
        'text' => 'A blue lake shaped like a half moon, open only in summer. Reached through the Atal Tunnel from Manali.',
        'see' => ['Chandratal Lake', 'Sissu', 'Batal', 'Chandra river valley'],
        'packages' => ['chandratal-lahaul'],
    ],
    'delhi' => [
        'name' => 'Delhi', 'tagline' => 'India’s capital energy', 'image' => 'red-fort-delhi', 'altitude' => '216 m', 'best' => 'All year', 'drive' => 'On arrival day',
        'text' => 'A layered mix of Mughal heritage, colonial landmarks, buzzing markets and endless food streets. Delhi is a natural gateway for India’s classic heritage circuits.',
        'see' => ['Red Fort', 'India Gate', 'Chandni Chowk', 'Jama Masjid', 'Qutub Minar'],
        'packages' => ['golden-triangle-delhi-agra-jaipur', 'delhi-agra-weekend'],
    ],
    'agra' => [
        'name' => 'Agra', 'tagline' => 'The city of marble and memory', 'image' => 'taj-mahal-agra', 'altitude' => '169 m', 'best' => 'All year', 'drive' => '3–5 hrs from Delhi',
        'text' => 'Home to the Taj Mahal and a remarkable Mughal legacy, Agra gives you one of India’s most memorable heritage experiences in just a day or two.',
        'see' => ['Taj Mahal', 'Agra Fort', 'Mehtab Bagh', 'local marble markets', 'Fatehpur Sikri day trip'],
        'packages' => ['golden-triangle-delhi-agra-jaipur', 'delhi-agra-weekend'],
    ],
    'rajasthan' => [
        'name' => 'Rajasthan', 'tagline' => 'Royal forts and desert skies', 'image' => 'hawa-mahal-jaipur', 'altitude' => 'Varies by city', 'best' => 'October – March', 'drive' => 'Flexible by route',
        'text' => 'From Jaipur’s palace lanes to Jaisalmer’s golden desert dunes, Rajasthan brings together a rich mix of history, architecture and warm hospitality.',
        'see' => ['Jaipur', 'Jodhpur', 'Jaisalmer', 'Udaipur', 'Desert camps'],
        'packages' => ['rajasthan-heritage-trail', 'golden-triangle-delhi-agra-jaipur'],
    ],
    'nainital' => ['name' => 'Nainital', 'tagline' => 'A hill town around a lake', 'image' => 'nainital', 'altitude' => 'Varies by route', 'best' => 'March–June, September–November', 'drive' => 'Route planned around pickup', 'text' => 'Spend time by Naini Lake, browse Mall Road and visit Naina Devi Temple on a relaxed Kumaon hill-station break.', 'see' => ['Boating on Naini Lake', 'Mall Road', 'Naina Devi Temple'], 'packages' => ['nainital']],
    'bhimtal' => ['name' => 'Bhimtal Lake', 'tagline' => 'Lake island in the Kumaon hills', 'image' => 'bhimtal', 'altitude' => 'Varies by route', 'best' => 'March-June, September-November', 'drive' => 'Route planned around pickup', 'text' => 'Bhimtal Lake sits in the hill town of Bhimtal, Uttarakhand, with calm water, boating and views of the small island at the centre of the lake.', 'see' => ['Bhimtal Lake', 'Lake island views', 'Boating', 'Lakeside walks'], 'packages' => ['bhimtal']],
    'mussoorie' => ['name' => 'Mussoorie', 'tagline' => 'The Queen of Hills', 'image' => 'george-everest-peak', 'altitude' => 'Varies by route', 'best' => 'September–June', 'drive' => 'Route planned around pickup', 'text' => 'Sunrise from George Everest Peak, waterfalls, viewpoints, lakes and scenic walks make Mussoorie an easy-going hill escape.', 'see' => ['George Everest Peak', 'Mall Road', 'Mussoorie Lake', 'Ropeway to Bhatta Falls', 'Lal Tibba', 'Scenic Cafe', 'Cloud End', 'Kempty Water Fall'], 'packages' => ['mussoorie']],
    'chakrata' => ['name' => 'Chakrata', 'tagline' => 'Quiet hills, forests & waterfalls', 'image' => 'snow-peaks', 'altitude' => 'Varies by route', 'best' => 'March–June, September–November', 'drive' => 'Route planned around pickup', 'text' => 'Chakrata is a peaceful hill destination known for forest viewpoints, waterfalls, caves and a slower mountain pace.', 'see' => ['Chakrata View Point', 'Tiger Falls', 'Budher Caves', 'Deoban Chakrata', 'Chilmiri Neck', 'Ram Tal Horticultural Garden'], 'packages' => ['chakrata', 'solo-chakrata-nature-activity']],
    'rishikesh' => ['name' => 'Rishikesh', 'tagline' => 'The Ganges, yoga & adventure', 'image' => 'rishikesh', 'altitude' => 'Varies by route', 'best' => 'February–May, August–October', 'drive' => 'Route planned around pickup', 'text' => 'A riverside town known for yoga, spiritual landmarks, Beatles Ashram and seasonal river rafting.', 'see' => ['Lakshman Jhula', 'Beatles Ashram', 'River rafting, when available', 'Yoga retreats'], 'packages' => ['rishikesh', 'solo-rishikesh-activity-break']],
    'haridwar' => ['name' => 'Haridwar', 'tagline' => 'Ganga aarti & temple town', 'image' => 'rishikesh', 'altitude' => 'Varies by route', 'best' => 'All year', 'drive' => 'Route planned around pickup', 'text' => 'Haridwar is a sacred Ganga city known for Har Ki Pauri, evening aarti and hilltop temple visits.', 'see' => ['Har Ki Pauri', 'Mansa Devi Temple', 'Chandi Devi Temple'], 'packages' => ['haridwar']],
    'auli' => ['name' => 'Auli', 'tagline' => 'Snow slopes & Himalayan views', 'image' => 'snow-peaks', 'altitude' => 'Varies by route', 'best' => 'November–March for snow and skiing', 'drive' => 'Route planned around pickup', 'text' => 'A high-altitude mountain destination for winter scenery and skiing when snow and local operations allow.', 'see' => ['Ski slopes', 'Cable car, subject to operations', 'Himalayan viewpoints'], 'packages' => ['auli']],
    'yamunotri' => ['name' => 'Yamunotri', 'tagline' => 'Source of the River Yamuna', 'image' => 'snow-peaks', 'altitude' => 'Varies by route', 'best' => 'May–October, subject to shrine opening', 'drive' => 'Route planned around pickup', 'text' => 'The first stop of the traditional Char Dham Yatra, Yamunotri is revered as the source of the River Yamuna and is known for its natural hot springs.', 'see' => ['Yamunotri Temple', 'Source region of the River Yamuna', 'Natural hot springs', 'Himalayan trekking route'], 'packages' => ['char-dham-hemkund-sahib-yatra']],
    'gangotri' => ['name' => 'Gangotri', 'tagline' => 'Origin of the holy River Ganga', 'image' => 'snow-peaks', 'altitude' => 'Varies by route', 'best' => 'May–October, subject to shrine opening', 'drive' => 'Route planned around pickup', 'text' => 'Gangotri is a sacred Himalayan shrine associated with the origin of the River Ganga, surrounded by dramatic valleys and high mountain scenery.', 'see' => ['Gangotri Temple', 'Bhagirathi River', 'Greater Himalayan views', 'Pilgrimage route stops'], 'packages' => ['char-dham-hemkund-sahib-yatra']],
    'kedarnath' => ['name' => 'Kedarnath', 'tagline' => 'Jyotirlinga shrine of Lord Shiva', 'image' => 'snow-peaks', 'altitude' => 'Varies by route', 'best' => 'May–October, subject to shrine opening', 'drive' => 'Road travel to Gaurikund, then trek', 'text' => 'Kedarnath is one of the 12 sacred Jyotirlingas of Lord Shiva, reached by a demanding 16–18 km trek from Gaurikund.', 'see' => ['Kedarnath Temple', '16–18 km trek from Gaurikund', 'Mandakini valley', 'High Himalayan views'], 'packages' => ['char-dham-hemkund-sahib-yatra']],
    'badrinath' => ['name' => 'Badrinath', 'tagline' => 'Holy shrine of Lord Vishnu', 'image' => 'snow-peaks', 'altitude' => 'Varies by route', 'best' => 'May–October, subject to shrine opening', 'drive' => 'Route planned around pickup', 'text' => 'Badrinath is a revered Char Dham shrine dedicated to Lord Vishnu, set amid the high Himalayan landscape of Uttarakhand.', 'see' => ['Badrinath Temple', 'Lord Vishnu shrine', 'Mountain valley views', 'Pilgrimage route stops'], 'packages' => ['char-dham-hemkund-sahib-yatra']],
    'hemkund-sahib' => ['name' => 'Hemkund Sahib', 'tagline' => 'High-altitude Gurudwara by a glacial lake', 'image' => 'snow-peaks', 'altitude' => 'Varies by route', 'best' => 'June–October, subject to route opening', 'drive' => 'Road travel to Govindghat, then trek via Ghangaria', 'text' => 'Hemkund Sahib is among the world’s highest Gurudwaras, located beside a glacial lake and accessed by trek from Ghangaria.', 'see' => ['Hemkund Sahib Gurudwara', 'Glacial lake', 'Trek from Ghangaria', 'High Himalayan scenery'], 'packages' => ['char-dham-hemkund-sahib-yatra']],
    'jim-corbett' => ['name' => 'Jim Corbett National Park', 'tagline' => 'Forest & wildlife', 'image' => 'jim-corbett', 'altitude' => 'Varies by zone', 'best' => 'November–June; zone access varies', 'drive' => 'Route planned around pickup', 'text' => 'Plan a park visit around available safari zones, permits and current local conditions.', 'see' => ['Jeep safaris, subject to permits', 'Wildlife spotting', 'Kosi River scenery'], 'packages' => ['jim-corbett']],
    'srinagar' => ['name' => 'Srinagar', 'tagline' => 'Dal Lake, houseboats & Mughal gardens', 'image' => 'srinagar', 'altitude' => 'Varies by route', 'best' => 'April–October for sightseeing', 'drive' => 'Route planned around pickup', 'text' => 'Srinagar is famous for Dal Lake shikara rides, houseboats and Mughal gardens like Shalimar Bagh and Nishat Garden.', 'see' => ['Dal Lake shikara rides', 'Houseboats', 'Shalimar Bagh', 'Nishat Garden'], 'packages' => ['kashmir-valley']],
    'gulmarg' => ['name' => 'Gulmarg', 'tagline' => 'Skiing, gondola & Apharwat Peak', 'image' => 'snow-peaks', 'altitude' => 'Varies by route', 'best' => 'April–October for meadows; winter for snow', 'drive' => 'Route planned around pickup', 'text' => 'Gulmarg is known for skiing, the high-altitude Gulmarg Gondola and views around Apharwat Peak.', 'see' => ['Skiing in winter', 'Gulmarg Gondola', 'Apharwat Peak', 'Alpine meadows'], 'packages' => ['kashmir-valley']],
    'pahalgam' => ['name' => 'Pahalgam', 'tagline' => 'Betaab Valley, Aru Valley & Lidder River', 'image' => 'forest-river', 'altitude' => 'Varies by route', 'best' => 'April–October', 'drive' => 'Route planned around pickup', 'text' => 'Pahalgam is a scenic health resort featuring Betaab Valley, Aru Valley and the Lidder River.', 'see' => ['Betaab Valley', 'Aru Valley', 'Lidder River', 'Pine forest scenery'], 'packages' => ['kashmir-valley']],
    'sonamarg' => ['name' => 'Sonamarg', 'tagline' => 'The Meadow of Gold', 'image' => 'sonamarg', 'altitude' => 'Varies by route', 'best' => 'April–October', 'drive' => 'Route planned around pickup', 'text' => 'Sonamarg, called the Meadow of Gold, offers glacier views, green valley scenery and access to the Thajiwas Glacier.', 'see' => ['Meadow of Gold scenery', 'Thajiwas Glacier', 'Kashmir Valley views', 'High mountain trails'], 'packages' => ['kashmir-valley']],
    'jammu-katra' => ['name' => 'Katra / Vaishno Devi', 'tagline' => 'Base town for Vaishno Devi Mandir', 'image' => 'snow-peaks', 'altitude' => 'Varies by route', 'best' => 'Plan around your dates', 'drive' => 'Route planned around pickup', 'text' => 'Katra is the base town for the sacred pilgrimage to the Vaishno Devi Mandir shrine.', 'see' => ['Katra base town', 'Vaishno Devi Mandir shrine', 'Pilgrimage route arrangements'], 'packages' => ['katra-vaishno-devi', 'jammu-katra-patnitop']],
    'patnitop' => ['name' => 'Patnitop', 'tagline' => 'A quiet Jammu hill escape', 'image' => 'snow-peaks', 'altitude' => 'Varies by route', 'best' => 'Plan around your dates', 'drive' => 'Route planned around pickup', 'text' => 'Add a restorative mountain stay in Patnitop to a Jammu and Katra pilgrimage or holiday route.', 'see' => ['Mountain scenery', 'Easy walks', 'A relaxed stop after Katra'], 'packages' => ['jammu-katra-patnitop']],
    'dharamshala' => ['name' => 'Dharamshala', 'tagline' => 'Dhauladhar views & local heritage', 'image' => 'dharamshala', 'altitude' => 'Varies by route', 'best' => 'Plan around your dates', 'drive' => 'Route planned around pickup', 'text' => 'A Kangra Valley city set against the Dhauladhar range, with cultural landmarks, forest walks and a celebrated cricket ground.', 'see' => ['HPCA Cricket Stadium', 'War Memorial', 'Norbulingka Institute', 'St. John in the Wilderness Church', 'Kangra Art Museum'], 'packages' => ['dharamshala-mcleodganj', 'solo-dharamshala-triund-activity']],
    'amritsar' => ['name' => 'Amritsar', 'tagline' => 'Sikh heritage & Punjabi hospitality', 'image' => 'amritsar-golden-temple', 'altitude' => '234 m', 'best' => 'October–March', 'drive' => 'About 2 hrs from Pathankot', 'text' => 'A vibrant heritage city centered on the Golden Temple, with moving history, lively markets and the daily border ceremony nearby.', 'see' => ['Golden Temple (Harmandir Sahib)', 'Jallianwala Bagh', 'Partition Museum', 'Wagah–Attari border ceremony', 'Gobindgarh Fort'], 'packages' => ['amritsar-pathankot-dalhousie', 'amritsar-katra']],
    'pathankot' => ['name' => 'Pathankot', 'tagline' => 'Gateway to Punjab and the hills', 'image' => 'https://commons.wikimedia.org/wiki/Special:FilePath/Pathankot_City.jpg?width=1200', 'image_credit' => ['Vishalsaini · CC BY-SA 3.0', 'https://commons.wikimedia.org/wiki/File:Pathankot_City.jpg'], 'altitude' => '332 m', 'best' => 'October–March', 'drive' => 'Gateway city for nearby hill routes', 'text' => 'Use Pathankot as a base for local heritage and lakeside stops, with routes onward to Himachal and Jammu planned around your trip.', 'see' => ['Ranjit Sagar Dam', 'Nurpur Fort', 'Shahpurkandi Fort', 'Mukteshwar Temple', 'Kathaluar Wildlife Sanctuary', 'Bhasoli Bridge', 'Mini Goa', 'Thar and Uparala'], 'packages' => ['pathankot-nurpur-dharamshala-kangra', 'amritsar-pathankot-dalhousie']],
    'chandigarh' => ['name' => 'Chandigarh', 'tagline' => 'Garden city & modernist landmarks', 'image' => 'https://commons.wikimedia.org/wiki/Special:FilePath/Chandigarh_Rock_Garden.jpg?width=1200', 'image_credit' => ['Klaus Nahr · CC BY-SA 2.0', 'https://commons.wikimedia.org/wiki/File:Chandigarh_Rock_Garden.jpg'], 'altitude' => '321 m', 'best' => 'October–March', 'drive' => 'Around 4 hrs from Shimla', 'text' => 'A planned city known for its architecture, open green spaces and the sculptural Rock Garden.', 'see' => ['Rock Garden', 'Sukhna Lake', 'Capitol Complex', 'Rose Garden', 'Sector 17 Plaza'], 'packages' => []],
    'chail' => ['name' => 'Chail', 'tagline' => 'Quiet forests & a hilltop palace', 'image' => 'https://commons.wikimedia.org/wiki/Special:FilePath/Chail_Palace.jpg?width=1200', 'image_credit' => ['Shrey.ashi · CC BY 4.0', 'https://commons.wikimedia.org/wiki/File:Chail_Palace.jpg'], 'altitude' => '2,250 m', 'best' => 'March–June, September–November', 'drive' => 'About 2 hrs from Shimla', 'text' => 'A peaceful mountain retreat of deodar forests, heritage buildings and broad Himalayan views.', 'see' => ['Chail Palace', 'Chail Cricket Ground', 'Sadhupul', 'Kali Tibba Temple'], 'packages' => []],
    'palampur' => ['name' => 'Palampur', 'tagline' => 'Tea gardens below the Dhauladhar', 'image' => 'https://commons.wikimedia.org/wiki/Special:FilePath/Palampur_tea_plantation%2C_Himachal_Pradesh%2C_India.jpg?width=1200', 'image_credit' => ['UnpetitproleX · CC BY-SA 4.0', 'https://commons.wikimedia.org/wiki/File:Palampur_tea_plantation,_Himachal_Pradesh,_India.jpg'], 'altitude' => '1,220 m', 'best' => 'March–June, September–November', 'drive' => 'About 1 hr from Dharamshala', 'text' => 'A relaxed Kangra Valley town framed by tea gardens, pine country and the Dhauladhar range.', 'see' => ['Palampur tea gardens', 'Tashi Jong Monastery', 'Neugal Khad', 'Andretta artists’ village'], 'packages' => []],
    'mcleod-ganj' => ['name' => 'McLeod Ganj', 'tagline' => 'Tibetan culture & mountain trails', 'image' => 'https://commons.wikimedia.org/wiki/Special:FilePath/McLeod_Ganj_main_street.jpg?width=1200', 'image_credit' => ['John Hill · CC BY-SA 3.0 / GFDL', 'https://commons.wikimedia.org/wiki/File:McLeod_Ganj_main_street.jpg'], 'altitude' => '2,082 m', 'best' => 'March–June, September–November', 'drive' => 'About 30 min from Dharamshala', 'text' => 'A lively hill town known for Tibetan culture, monasteries, cafés and access to the Dhauladhar foothills.', 'see' => ['Tsuglagkhang Complex', 'Namgyal Monastery', 'Bhagsu Nag Temple and waterfall', 'Tibetan Museum', 'Triund trail'], 'packages' => ['dharamshala-mcleodganj', 'solo-dharamshala-triund-activity']],
    'dalhousie-khajjiar' => ['name' => 'Dalhousie', 'tagline' => 'Colonial hill town & pine forests', 'image' => 'https://commons.wikimedia.org/wiki/Special:FilePath/Dalhousie_View_l_Himachal_Pradesh.jpg?width=1200', 'image_credit' => ['Piyush Tripathi · CC BY-SA 4.0', 'https://commons.wikimedia.org/wiki/File:Dalhousie_View_l_Himachal_Pradesh.jpg'], 'altitude' => '1,970 m', 'best' => 'March–June, September–November', 'drive' => 'About 1 hr from Khajjiar', 'text' => 'A hillside town of old churches, quiet walking paths and views across the Dhauladhar range.', 'see' => ['St. John’s Church', 'Subhash Baoli', 'Panchpula', 'Gandhi Chowk', 'Dainkund Peak'], 'packages' => ['dalhousie-khajjiar']],
    'khajjiar' => ['name' => 'Khajjiar', 'tagline' => 'Meadows, cedar forest & mountain views', 'image' => 'khajjiar', 'altitude' => '1,920 m', 'best' => 'March–June', 'drive' => 'About 1 hr from Dalhousie', 'text' => 'A broad alpine meadow around Khajjiar Lake, surrounded by cedar forest and often visited as a day trip from Dalhousie.', 'see' => ['Khajjiar Lake', 'Khajji Nag Temple', 'Meadow walks', 'Chamba district scenery'], 'packages' => ['dalhousie-khajjiar']],
    'kufri' => ['name' => 'Kufri', 'tagline' => 'Forest walks & highland views', 'image' => 'https://commons.wikimedia.org/wiki/Special:FilePath/Kufri_in_Shimla_3.jpg?width=1200', 'altitude' => '2,510 m', 'best' => 'April–June; winter for snow', 'drive' => 'About 1 hr from Shimla', 'text' => 'A high-altitude outing near Shimla for mountain scenery, forest trails and seasonal snow.', 'see' => ['Himalayan Nature Park', 'Mahasu Peak', 'Forest walks', 'Seasonal snow views'], 'packages' => ['shimla-local']],
    'narkanda' => ['name' => 'Narkanda', 'tagline' => 'Apple country & Hatu Peak', 'image' => 'https://commons.wikimedia.org/wiki/Special:FilePath/Narkanda.jpg?width=1200', 'image_credit' => ['Skmishraindia · CC0', 'https://commons.wikimedia.org/wiki/File:Narkanda.jpg'], 'altitude' => '2,708 m', 'best' => 'April–June, September–February', 'drive' => 'About 2 hrs from Shimla', 'text' => 'A mountain town on the old Hindustan–Tibet Road, with orchards, forest drives and a high ridge above town.', 'see' => ['Hatu Peak and temple', 'Tannu Jubbar Lake', 'Apple orchards', 'Winter ski slopes'], 'packages' => ['shimla-spiti-kinnaur']],
    'kangra' => ['name' => 'Kangra', 'tagline' => 'Fort heritage & temple country', 'image' => 'https://commons.wikimedia.org/wiki/Special:FilePath/Kangra_Fort%2C_Kangra%2C_Himachal_Pradesh.jpg?width=1200', 'image_credit' => ['Brahmavadini · CC BY 4.0', 'https://commons.wikimedia.org/wiki/File:Kangra_Fort,_Kangra,_Himachal_Pradesh.jpg'], 'altitude' => '733 m', 'best' => 'March–June, September–November', 'drive' => 'About 1 hr from Dharamshala', 'text' => 'A historic valley town beneath the Dhauladhar range, known for its fort, temples and views across the Kangra Valley.', 'see' => ['Kangra Fort', 'Brajeshwari Devi Temple', 'Maharana Pratap Sagar', 'Masrur rock-cut temples'], 'packages' => ['pathankot-nurpur-dharamshala-kangra']],
    'uttarakhand' => ['name' => 'Uttarakhand', 'tagline' => 'Lake towns & Himalayan escapes', 'image' => 'bhimtal', 'altitude' => 'Varies by route', 'best' => 'Plan by destination and season', 'drive' => 'Route planned around pickup', 'text' => 'Explore Uttarakhand through its lake towns, hill stations, river retreats, pilgrimage routes and high mountain viewpoints.', 'see' => ['Bhimtal', 'Nainital', 'Mussoorie', 'Chakrata', 'Rishikesh', 'Haridwar', 'Auli', 'Jim Corbett National Park'], 'packages' => []],
    'jammu-kashmir' => ['name' => 'Jammu & Kashmir', 'tagline' => 'Lakes, valleys & mountain journeys', 'image' => 'srinagar', 'altitude' => 'Varies by route', 'best' => 'Plan by destination and season', 'drive' => 'Route planned around pickup', 'text' => 'Plan a journey through Kashmir’s lake towns, mountain valleys, glacier views and Jammu pilgrimage routes.', 'see' => ['Srinagar', 'Gulmarg', 'Pahalgam', 'Sonamarg', 'Katra / Vaishno Devi', 'Patnitop'], 'packages' => []],
];

$destinationGroups = [
    'punjab' => [
        'title' => 'Punjab', 'image' => 'amritsar-golden-temple',
        'description' => 'Explore Punjab’s cultural landmarks and gateway cities.',
        'items' => ['Amritsar', 'Pathankot', 'Chandigarh'],
    ],
    'himachal-pradesh' => [
        'title' => 'Himachal Pradesh', 'image' => 'dharamshala',
        'description' => 'Plan a Himachal journey across hill towns, valleys and heritage sites.',
        'items' => ['Chail', 'Palampur', 'Dharamshala', 'McLeod Ganj', 'Dalhousie', 'Khajjiar', 'Shimla', 'Kufri', 'Narkanda', 'Kangra'],
    ],
    'other-regions' => [
        'title' => 'Other regions', 'image' => 'hawa-mahal-jaipur',
        'description' => 'Explore more of North India across the plains, valleys and historic cities.',
        'items' => ['Uttarakhand', 'Jammu & Kashmir', 'Delhi', 'Rajasthan'],
    ],
    'pathankot-attractions' => [
        'title' => 'Pathankot attractions', 'image' => 'ranjit-sagar-dam',
        'description' => 'Add local nature and heritage stops around Pathankot to your route.',
        'items' => ['Bhasoli Bridge', 'Mini Goa', 'Ranjit Sagar Dam', 'Thar', 'Uparala', 'Kathaluar Wildlife Sanctuary', 'Mukteshwar Temple', 'Shahpurkandi Fort', 'Nurpur Fort'],
    ],
];
$defaultDestinationGroups = $destinationGroups;
require_once dirname(__DIR__) . '/backend/database.php';
$storedDestinationGroups = app_db_catalog('destination_groups');
if ($storedDestinationGroups !== null) {
    $destinationGroups = $storedDestinationGroups;
}
$defaultDestinations = $destinations;
$defaultDestinationGroups = $defaultDestinations;
$storedDestinations = app_db_catalog('destination_groups');
if ($storedDestinations !== null) {
    $newDestinationSlugs = ['bhimtal', 'chakrata', 'haridwar', 'yamunotri', 'gangotri', 'kedarnath', 'badrinath', 'hemkund-sahib'];
    $db = app_db();
    if ($db) {
        $insertDestination = $db->prepare('INSERT IGNORE INTO destination_groups (slug, payload) VALUES (?, ?)');
        foreach ($newDestinationSlugs as $slug) {
            if (isset($destinations[$slug]) && !isset($storedDestinations[$slug])) {
                $insertDestination->execute([$slug, json_encode($destinations[$slug], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)]);
                $storedDestinations[$slug] = $destinations[$slug];
            }
        }
        $db->exec('CREATE TABLE IF NOT EXISTS catalog_migrations (migration_key VARCHAR(190) PRIMARY KEY, applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $migrationKey = 'requested-destinations-refresh-2026-10-v2';
        $migrationCheck = $db->prepare('SELECT 1 FROM catalog_migrations WHERE migration_key = ?');
        $migrationCheck->execute([$migrationKey]);
        if (!$migrationCheck->fetchColumn()) {
            $refreshDestinationSlugs = ['manali', 'kasol', 'bhimtal', 'mussoorie', 'chakrata', 'rishikesh', 'haridwar', 'srinagar', 'gulmarg', 'pahalgam', 'sonamarg', 'jammu-katra', 'dharamshala', 'mcleod-ganj', 'uttarakhand', 'jammu-kashmir'];
            $updateDestination = $db->prepare('INSERT INTO destination_groups (slug, payload) VALUES (?, ?) ON DUPLICATE KEY UPDATE payload = VALUES(payload)');
            foreach ($refreshDestinationSlugs as $slug) {
                if (!isset($destinations[$slug])) continue;
                $destinations[$slug]['active'] = app_catalog_is_active($storedDestinations[$slug] ?? []);
                $updateDestination->execute([$slug, json_encode($destinations[$slug], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)]);
                $storedDestinations[$slug] = $destinations[$slug];
            }
            $migrationWrite = $db->prepare('INSERT IGNORE INTO catalog_migrations (migration_key) VALUES (?)');
            $migrationWrite->execute([$migrationKey]);
        }
        $migrationKey = 'mussoorie-george-everest-destination-2026-10-v1';
        $migrationCheck->execute([$migrationKey]);
        if (!$migrationCheck->fetchColumn() && isset($destinations['mussoorie'])) {
            $destinations['mussoorie']['active'] = app_catalog_is_active($storedDestinations['mussoorie'] ?? []);
            $updateDestination = $db->prepare('INSERT INTO destination_groups (slug, payload) VALUES (?, ?) ON DUPLICATE KEY UPDATE payload = VALUES(payload)');
            $updateDestination->execute(['mussoorie', json_encode($destinations['mussoorie'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)]);
            $storedDestinations['mussoorie'] = $destinations['mussoorie'];
            $migrationWrite = $db->prepare('INSERT IGNORE INTO catalog_migrations (migration_key) VALUES (?)');
            $migrationWrite->execute([$migrationKey]);
        }
    }
    $dynamicDestinations = array_filter($storedDestinations, static fn($destination) => isset($destination['name'], $destination['tagline'], $destination['text'], $destination['see']));
    if ($dynamicDestinations) {
        $destinations = array_replace($destinations, $dynamicDestinations);
    }
}
$destinations = app_catalog_order($destinations, 'destinations');
$allDestinations = $destinations;
$destinations = array_filter($destinations, 'app_catalog_is_active');
$destinationGroups = $destinations;
$driveTimes = array_values(array_filter($driveTimes, static fn($drive) => isset($destinations[$drive[2]])));

/* ---------------------------------------------------------------------------
 * Vehicles. 'group' lists the group-size filters a vehicle suits.
 * ------------------------------------------------------------------------- */
$vehicles = [
    [
        'name' => 'Maruti Swift', 'type' => 'car', 'tag' => 'Hatchback', 'group' => 'small',
        'image' => 'assets/images/car/fleet-swift.jpg', 'alt' => 'White Maruti Suzuki Swift hatchback',
        'summary' => 'Small car for 1–4 people. Dzire sedan & Alto also available.',
        'details' => 'A small, comfortable car that is easy on fuel. Good for couples and small families on normal highway and hill roads. Ask for the Dzire if you need more boot space.',
        'seats' => '4', 'bags' => '2 bags', 'extra' => ['fa-snowflake', 'AC'],
        'best' => 'City & hill drives', 'terrain' => 'Paved highways',
        'features' => ['Air conditioning', 'Easy to park in hill towns', 'Economical on long drives', 'Dzire sedan & Alto on request'],
        'routes' => ['Shimla trips', 'Shimla local', 'Kullu · Manali'],
    ],
    [
        'name' => 'Maruti Ertiga', 'type' => 'suv', 'tag' => 'MUV', 'group' => 'medium',
        'image' => 'assets/images/car/fleet-ertiga.jpg', 'alt' => 'White Maruti Suzuki Ertiga MPV',
        'summary' => 'Seven-seater for families of 5–6 people.',
        'details' => 'Three rows of seats, so the whole family travels together. Smooth and comfortable on long drives and on hill roads.',
        'seats' => '6', 'bags' => '3 bags', 'extra' => ['fa-snowflake', 'AC'],
        'best' => 'Family trips', 'terrain' => 'Highways & hill roads',
        'features' => ['Three-row seating', 'Rear AC vents', 'Space for 3 suitcases', 'Great value for families'],
        'routes' => ['Manali trips', 'Shimla · Kullu · Manali', 'Kasol'],
    ],
    [
        'name' => 'Toyota Innova Crysta', 'type' => 'suv', 'tag' => 'Premium MUV', 'group' => 'medium',
        'image' => 'assets/images/car/fleet-innova.jpg', 'alt' => 'White Toyota Innova Crysta',
        'summary' => 'Big, powerful and very comfortable — best for long trips.',
        'details' => 'Our most booked vehicle for long trips. Comfortable seats, a strong engine and a smooth ride make long days on mountain roads much easier.',
        'seats' => '6–7', 'bags' => '4 bags', 'extra' => ['fa-snowflake', 'AC'],
        'best' => 'Long journeys', 'terrain' => 'All-weather hill roads',
        'features' => ['Captain seats in the middle row', 'Powerful diesel for steep climbs', 'Generous luggage room', 'Premium, quiet cabin'],
        'routes' => ['Shimla to Spiti via Kinnaur', 'Manali · Atal Tunnel', 'Multi-day circuits'],
    ],
    [
        'name' => 'Suzuki Jimny 4×4', 'type' => 'suv', 'tag' => '4×4', 'group' => 'small',
        'image' => 'assets/images/car/fleet-jimny-4x4.jpg', 'alt' => 'Suzuki Jimny 4x4 with roof rack on a hillside',
        'summary' => 'Small 4×4 for rough roads in Spiti and Chandratal.',
        'details' => 'A real 4×4. Where the good road ends — near Kaza, Chandratal or far Kinnaur villages — the Jimny keeps going.',
        'seats' => '4', 'bags' => '2 bags', 'extra' => ['fa-mountain', '4WD'],
        'best' => 'Off-road & Spiti', 'terrain' => 'Rough & unpaved tracks',
        'features' => ['Low-range 4×4 gearbox', 'High ground clearance', 'Compact for narrow roads', 'Roof rack for extra luggage'],
        'routes' => ['Kaza · Chandratal', 'Chitkul · Sangla', 'Pin Valley'],
    ],
    [
        'name' => 'Tempo Traveller', 'type' => 'group', 'tag' => 'Mini coach', 'group' => 'large',
        'image' => 'assets/images/car/fleet-traveller.jpg', 'alt' => 'White Force Tempo Traveller on a Himalayan mountain road',
        'summary' => 'Mini bus for groups of 12–17 people.',
        'details' => 'The usual choice for group trips. Push-back seats, a high roof and a roof carrier, so everyone and all the bags go in one vehicle.',
        'seats' => '12–17', 'bags' => 'Roof carrier', 'extra' => ['fa-snowflake', 'AC'],
        'best' => 'Group journeys', 'terrain' => 'Highways & hill roads',
        'features' => ['Push-back seats', 'Roof carrier for luggage', 'High roof for easy movement', 'Music system'],
        'routes' => ['Shimla · Manali circuits', 'Corporate & school trips', 'Wedding groups'],
    ],
    [
        'name' => 'Force Urbania', 'type' => 'group', 'tag' => 'Luxury van', 'group' => 'large',
        'image' => 'assets/images/car/fleet-urbania-van.jpg', 'alt' => 'Premium passenger van in a Himalayan valley',
        'summary' => 'Premium van for groups who want extra comfort.',
        'details' => 'A newer, more comfortable group van: big windows, reclining seats and a quieter ride.',
        'seats' => '10–17', 'bags' => 'Large boot', 'extra' => ['fa-snowflake', 'AC'],
        'best' => 'Premium groups', 'terrain' => 'Highways & hill roads',
        'features' => ['Panoramic windows', 'Individual reclining seats', 'Quieter, car-like ride', 'USB charging points'],
        'routes' => ['Premium family tours', 'Corporate offsites', 'Airport transfers'],
    ],
];

$groupSizes = ['all' => 'Any group size', 'small' => '1–4 travellers', 'medium' => '5–7 travellers', 'large' => '8–17 travellers'];

$defaultVehicles = $vehicles;
require_once dirname(__DIR__) . '/backend/database.php';
$databaseVehicles = app_db_catalog('taxis');
if ($databaseVehicles !== null) {
    $vehicles = array_values($databaseVehicles);
    foreach ($vehicles as &$vehicle) {
        $imageFile = basename((string) ($vehicle['image'] ?? ''));
        if (preg_match('/^(?:fleet|car)-.+\.jpg$/i', $imageFile)) {
            $vehicle['image'] = 'assets/images/car/' . $imageFile;
        }
    }
    unset($vehicle);
}

/* ---------------------------------------------------------------------------
 * Gallery photos. 'cat' drives the gallery filters.
 * ------------------------------------------------------------------------- */
$galleryCategories = [
    'all' => 'All photos', 'valleys' => 'Valleys & villages', 'lakes' => 'Lakes',
    'monasteries' => 'Temples & monasteries', 'snow' => 'Snow & peaks', 'towns' => 'Hill towns', 'adventure' => 'Camping & adventure',
];

$gallery = [
    ['file' => 'spiti-key-sunset', 'title' => 'Key Monastery at sunset',   'place' => 'Spiti Valley', 'cat' => 'monasteries'],
    ['file' => 'kinnaur-camps',    'title' => 'Riverside camps',           'place' => 'Kinnaur',      'cat' => 'adventure'],
    ['file' => 'chandratal-b',     'title' => 'Chandratal Lake',           'place' => 'Lahaul',       'cat' => 'lakes'],
    ['file' => 'hidimba',          'title' => 'Hidimba Devi Temple',       'place' => 'Manali',       'cat' => 'monasteries'],
    ['file' => 'shimla-train',     'title' => 'The toy train',             'place' => 'Shimla',       'cat' => 'towns'],
    ['file' => 'spiti-dhankar',    'title' => 'Dhankar Monastery',         'place' => 'Spiti Valley', 'cat' => 'monasteries'],
    ['file' => 'kinnaur-sangla',   'title' => 'Sangla valley',             'place' => 'Kinnaur',      'cat' => 'valleys'],
    ['file' => 'solang',           'title' => 'Solang Valley in winter',   'place' => 'Manali',       'cat' => 'snow'],
    ['file' => 'spiti-buddha',     'title' => 'Langza Buddha',             'place' => 'Spiti Valley', 'cat' => 'monasteries'],
    ['file' => 'shimla-church',    'title' => 'Christ Church',             'place' => 'Shimla',       'cat' => 'towns'],
    ['file' => 'kasol-river',      'title' => 'Parvati river',             'place' => 'Kasol',        'cat' => 'valleys'],
    ['file' => 'spiti-stars',      'title' => 'Camping under the stars',   'place' => 'Spiti Valley', 'cat' => 'adventure'],
    ['file' => 'kinnaur-autumn',   'title' => 'Autumn in Kinnaur',         'place' => 'Kinnaur',      'cat' => 'valleys'],
    ['file' => 'snow-peaks',       'title' => 'Snow trail',                'place' => 'Manali',       'cat' => 'snow'],
    ['file' => 'shimla-lodge',     'title' => 'Viceregal Lodge',           'place' => 'Shimla',       'cat' => 'towns'],
    ['file' => 'chandratal',       'title' => 'Crystal-clear Chandratal',  'place' => 'Lahaul',       'cat' => 'lakes'],
    ['file' => 'parvati',          'title' => 'Parvati valley meadows',    'place' => 'Kullu',        'cat' => 'valleys'],
    ['file' => 'camping',          'title' => 'High-altitude camping',     'place' => 'Himachal',     'cat' => 'adventure'],
    ['file' => 'spiti-key-snow',   'title' => 'Key Monastery in snow',     'place' => 'Spiti Valley', 'cat' => 'snow'],
    ['file' => 'manali-mall',      'title' => 'Mall Road',                 'place' => 'Manali',       'cat' => 'towns'],
    ['file' => 'trek-lahaul',      'title' => 'Trekking in Lahaul',        'place' => 'Lahaul',       'cat' => 'adventure'],
    ['file' => 'kinnaur-peaks',    'title' => 'Kinner Kailash range',      'place' => 'Kinnaur',      'cat' => 'snow'],
    ['file' => 'forest-river',     'title' => 'Forest river',              'place' => 'Kullu',        'cat' => 'valleys'],
    ['file' => 'shimla-snow',      'title' => 'Winter in Shimla',          'place' => 'Shimla',       'cat' => 'snow'],
];
