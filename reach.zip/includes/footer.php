<?php
/** Common footer: closes <main>, site footer, floating buttons, dialogs and scripts. */
$footerPackages = array_slice($packages, 0, 4, true);
?>
  </main>

  <footer class="site-footer">
    <!-- Layered mountain skyline rising out of the page into the footer -->
    <div class="footer-peaks" aria-hidden="true">
      <svg class="peaks-back" viewBox="0 0 1440 160" preserveAspectRatio="none"><path d="M0 160V96l70-34 60 22 90-62 80 44 70-30 110 70 90-52 60 26 100-70 90 48 70-22 110 64 80-38 70 20 90-56 70 30 60-18 70 12v162z"/></svg>
      <svg class="peaks-mid" viewBox="0 0 1440 160" preserveAspectRatio="none"><path d="M0 160v-40l90-40 70 26 110-58 90 46 60-18 120 62 80-34 90 28 110-66 80 40 90-20 100 50 90-36 80 26 90-30 40 12 50-10v58z"/></svg>
      <svg class="peaks-front" viewBox="0 0 1440 160" preserveAspectRatio="none"><path d="M0 160v-22l110-26 90 16 120-34 100 30 90-10 130 26 110-30 120 22 100-18 110 20 120-28 90 16 100-12 50 8v62z"/></svg>
    </div>
    <span class="footer-watermark" aria-hidden="true">NORTH INDIA</span>

    <div class="container">
<?php if (!$isHome): ?>
      <div class="footer-cta">
        <div>
          <h2>Planning a road trip?</h2>
          <p>Share your dates and group size. We’ll help shape a route and arrange the vehicle and stays.</p>
        </div>
        <div class="footer-cta-actions">
          <a class="btn btn-gold" href="<?= e(wa_link()) ?>" target="_blank" rel="noopener"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i> Chat on WhatsApp</a>
          <a class="btn btn-glass" href="contact.php">Send an enquiry</a>
        </div>
      </div>
<?php endif; ?>

      <!-- Quick contact -->
      <div class="footer-contact">
        <a class="fc-card" href="tel:<?= e($site['phoneLink']) ?>">
          <span class="fc-icon fc-amber"><i class="fa-solid fa-phone" aria-hidden="true"></i></span>
          <span class="fc-text"><small>Call for booking</small><b><?= e(site_phone_text()) ?></b></span>
          <i class="fa-solid fa-arrow-right fc-arrow" aria-hidden="true"></i>
        </a>
        <a class="fc-card" href="<?= e(wa_link()) ?>" target="_blank" rel="noopener">
          <span class="fc-icon fc-green"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i></span>
          <span class="fc-text"><small>WhatsApp</small><b>Chat with us</b></span>
          <i class="fa-solid fa-arrow-right fc-arrow" aria-hidden="true"></i>
        </a>
        <a class="fc-card" href="mailto:<?= e($site['email']) ?>">
          <span class="fc-icon fc-blue"><i class="fa-solid fa-envelope" aria-hidden="true"></i></span>
          <span class="fc-text"><small>Email us</small><b><?= e($site['email']) ?></b></span>
          <i class="fa-solid fa-arrow-right fc-arrow" aria-hidden="true"></i>
        </a>
        <a class="fc-card" href="<?= $site['address'] !== '' ? e('https://www.google.com/maps/search/?api=1&query=' . rawurlencode($site['address'])) : 'contact.php' ?>"<?= $site['address'] !== '' ? ' target="_blank" rel="noopener"' : '' ?>>
          <span class="fc-icon fc-amber"><i class="fa-solid fa-location-dot" aria-hidden="true"></i></span>
          <span class="fc-text"><small>Address</small><b><?= $site['address'] !== '' ? nl2br(e($site['address'])) : 'Contact us for our address' ?></b></span>
          <i class="fa-solid fa-arrow-right fc-arrow" aria-hidden="true"></i>
        </a>
      </div>
      <div class="footer-main">
        <div class="footer-about">
          <a class="brand footer-brand" href="index.php"><span class="brand-mark" aria-hidden="true"><img src="assets/logo.svg" alt="" width="170px" height="auto"></span></a>
          <p>Private road trips with a driver, vehicle and stays arranged around your route.</p>
          <div class="social-links">
            <a class="s-instagram" href="https://www.instagram.com/reachdreamtravel" target="_blank" rel="noopener" aria-label="Instagram"><i class="fa-brands fa-instagram" aria-hidden="true"></i></a>
            <a class="s-facebook" href="https://www.facebook.com/profile.php?id=61594993950885" target="_blank" rel="noopener" aria-label="Facebook"><i class="fa-brands fa-facebook-f" aria-hidden="true"></i></a>
            <a class="s-whatsapp" href="<?= e(wa_link()) ?>" target="_blank" rel="noopener" aria-label="WhatsApp"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i></a>
            <a class="s-email" href="mailto:<?= e($site['email']) ?>" aria-label="Email"><i class="fa-solid fa-envelope" aria-hidden="true"></i></a>
          </div>
        </div>

        <nav class="footer-col" aria-label="Explore">
          <h3>Explore</h3>
          <a href="index.php">Home</a>
          <a href="about.php">About us</a>
          <a href="packages.php">Tour packages</a>
          <a href="vehicles.php">Vehicles</a>
          <a href="gallery.php">Gallery</a>
          <a href="contact.php">Contact</a>
        </nav>

        <div class="footer-col footer-tours">
          <h3>Popular tours</h3>
<?php foreach ($footerPackages as $pkgSlug => $pkg): ?>
          <a class="ft-item" href="<?= e(package_url($pkgSlug)) ?>">
            <img src="<?= e(img($pkg['image'], true)) ?>" alt="" loading="lazy" width="120" height="90">
            <span><b><?= e($pkg['title']) ?></b><small><i class="fa-solid fa-clock" aria-hidden="true"></i> <?= e($pkg['duration']) ?></small></span>
          </a>
<?php endforeach; ?>
        </div>
      </div>

<?php require __DIR__ . '/footer-assurance.php'; ?>
      <div class="footer-bottom">
        <span>© <?= date('Y') ?> <?= e($site['name']) ?>. All rights reserved.</span>
        <nav class="footer-legal" aria-label="Legal"><a href="privacy.php">Privacy</a><a href="terms.php">Terms</a></nav>
        <!-- <span class="footer-made">Made with <i class="fa-solid fa-heart" aria-hidden="true"></i><span class="visually-hidden">love</span> in the Himalaya</span> -->
      </div>
    </div>
  </footer>

  <a class="back-to-top" href="#top" aria-label="Back to top"><svg viewBox="0 0 48 48" aria-hidden="true"><circle class="ring-track" cx="24" cy="24" r="22"/><circle class="ring-fill" cx="24" cy="24" r="22"/></svg><i class="fa-solid fa-arrow-up" aria-hidden="true"></i></a>
  <a class="whatsapp-float" href="<?= e(wa_link()) ?>" target="_blank" rel="noopener" aria-label="Chat with <?= e($site['name']) ?> on WhatsApp"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i><span>Chat with us</span></a>

  <dialog class="callback-dialog" id="callback-dialog" aria-labelledby="callback-title">
    <div class="callback-dialog-head"><div><span class="eyebrow">Talk through your plans</span><h2 id="callback-title"><?= $isHome ? 'Plan your trip' : 'Request a callback' ?></h2></div><button class="callback-close" type="button" aria-label="Close callback form"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button></div>
<?php if ($isHome): ?>
    <div class="callback-form-slot" data-callback-form-slot></div>
<?php else: ?>
    <p class="callback-copy" data-callback-copy>Share a few trip details and our team will get back to you.</p>
    <form class="trip-form callback-form" aria-label="Request a travel callback" novalidate>
      <input type="hidden" name="message" data-callback-message>
      <div class="field-row">
        <label class="field"><span>Your name</span><input type="text" name="name" autocomplete="name" placeholder="Full name" required></label>
        <label class="field"><span>Phone</span><input type="tel" name="phone" autocomplete="tel" placeholder="+91" required></label>
      </div>
      <label class="field"><span>Where to?</span><select name="destination"><?php trip_select_options(); ?></select></label>
      <div class="field-row">
        <label class="field"><span>Travel date</span><input type="date" name="date" min="<?= date('Y-m-d') ?>" placeholder="Select travel date"></label>
        <label class="field"><span>Travellers</span><input type="number" name="travellers" min="1" max="40" value="2" inputmode="numeric" placeholder="Number of travellers"></label>
      </div>
      <label class="field"><span>Vehicle</span><select name="vehicle"><?php vehicle_select_options(); ?></select></label>
      <input class="visually-hidden" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
      <button class="btn btn-gold w-100" type="submit">Request a callback <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></button>
      <p class="form-status" role="status" aria-live="polite" hidden></p>
    </form>
<?php endif; ?>
  </dialog>

  <dialog class="lightbox" id="lightbox" aria-label="Photo viewer"><button class="lightbox-close" aria-label="Close gallery"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button><button class="lightbox-prev" aria-label="Previous image"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i></button><img alt="Himachal scenery"><button class="lightbox-next" aria-label="Next image"><i class="fa-solid fa-chevron-right" aria-hidden="true"></i></button><div class="lightbox-caption"><b></b><small></small></div><span class="lightbox-count"></span></dialog>

  <script src="assets/bootstrap/bootstrap.bundle.min.js" defer></script>
  <script src="script.js?v=<?= (int) (filemtime(__DIR__ . '/../script.js') ?: 0) ?>" defer></script>
</body>
</html>
